function hideDetails(){
    document.getElementById('detailsContainer').style.display = "none";
}