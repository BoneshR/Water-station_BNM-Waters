function ShowSidebar(){
 
    document.getElementById('welcomeCustomerContainer').style.paddingRight = "40%";
    document.getElementById('filloutDetailsContainer').style.paddingRight = "40%";
    document.getElementById('formOrder').style.paddingRight = "40%";
}
function HideSidebar(){
    
    document.getElementById('welcomeCustomerContainer').style.paddingRight = "10%";
    document.getElementById('filloutDetailsContainer').style.paddingRight = "10%";
    document.getElementById('formOrder').style.paddingRight = "10%";
}