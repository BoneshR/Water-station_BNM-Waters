function ShowSidebar(){
    
    document.getElementById('orderSuccessMessage').style.paddingRight = "35%";
    document.getElementById('orderSuccessMessage').style.paddingLeft = "5%";
}
function HideSidebar(){
  
    document.getElementById('orderSuccessMessage').style.paddingRight = "20%";
    document.getElementById('orderSuccessMessage').style.paddingLeft = "20%";
}