var optionOne = document.getElementById('tanker1');
var optionTwo = document.getElementById('tanker2');
var optionThree = document.getElementById('tanker3');
var orderNum = document.getElementById('numberOrder');
var showTotal = document.getElementById('totalOrder');

optionOne.addEventListener("click", showContainerOne);
optionTwo.addEventListener("click", showContainerTwo);
optionThree.addEventListener("click", showContainerThree);

function showContainerOne(){
    document.getElementById('pictureOrderContainer').style.display = "block";

    document.getElementById('pictureOrder').src = "/BONESH-WRMS/images/truck1.png";

    document.getElementById('totalOrder').value = 500 * document.getElementById('numberOrder').value;

    optionTwo.checked = false;
    optionThree.checked = false;

    var optionChosen = "tanker1";
}

function showContainerTwo(){
    document.getElementById('pictureOrderContainer').style.display = "block";
    
    document.getElementById('pictureOrder').src = "/BONESH-WRMS/images/truck2.jpg";
    document.getElementById('totalOrder').value = 800 * document.getElementById('numberOrder').value;

    optionOne.checked = false;
    optionThree.checked = false;

    var optionChosen = "tanker2";
}

function showContainerThree(){
    document.getElementById('pictureOrderContainer').style.display = "block";
    
    document.getElementById('pictureOrder').src = "/BONESH-WRMS/images/truck3.png";
    document.getElementById('totalOrder').value = 1000 * document.getElementById('numberOrder').value;

    optionTwo.checked = false;
    optionOne.checked = false;

    var optionChosen = "tanker3";
}

function showOrder(){
    document.getElementById('proceedOrderContainer').style.display = "none";
    document.getElementById('submitOrderContainer').style.display = "block";
    
}

 