<?php


session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wrms";

$con = mysqli_connect('localhost','root', '');
if($con){
    echo "connection successful \n \n"; 
}
else{
    echo "connection un-successful";
}
mysqli_select_db($con,'wrms');

$username = $_POST['user'];
$email = $_POST['email'];
$password = $_POST['pass'];

$query = "select * from signin where email = '$email' && pass = '$password' ";
$result = mysqli_query($con , $query);

    if(mysqli_num_rows($result) == 1){
        header("Location: home.html");
        exit();
    }

    else{
        echo "\n Please Check Your Password and Try Again...!!!";
        exit();
    }

?>