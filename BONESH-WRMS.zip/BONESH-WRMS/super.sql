CREATE TABLE Customer
(
  Cust_id INT NOT NULL,
  Username INT NOT NULL,
  Password INT NOT NULL,
  Name INT NOT NULL,
  Email INT NOT NULL,
  PRIMARY KEY (Cust_id)
);

CREATE TABLE Order
(
  Order_id INT NOT NULL,
  Order_type INT NOT NULL,
  Payment INT NOT NULL,
  Ordered_date INT NOT NULL,
  Needed_date INT NOT NULL,
  Cust_id INT NOT NULL,
  PRIMARY KEY (Order_id),
  FOREIGN KEY (Cust_id) REFERENCES Customer(Cust_id)
);

CREATE TABLE Employees
(
  Emp_id INT NOT NULL,
  Emp_Name INT NOT NULL,
  Emp_Address INT NOT NULL,
  Emp_position INT NOT NULL,
  Emp_contact INT NOT NULL,
  PRIMARY KEY (Emp_id)
);

CREATE TABLE Admin
(
  Username INT NOT NULL,
  password INT NOT NULL,
  Admin_name INT NOT NULL,
  Admin_privilage INT NOT NULL,
  Admin_status INT NOT NULL,
  Emp_id INT NOT NULL,
  Order_id INT NOT NULL,
  PRIMARY KEY (Admin_name),
  FOREIGN KEY (Emp_id) REFERENCES Employees(Emp_id),
  FOREIGN KEY (Order_id) REFERENCES Order(Order_id)
);

CREATE TABLE Delivery
(
  D_status INT NOT NULL,
  D_id INT NOT NULL,
  Cust_id INT NOT NULL,
  Order_id INT NOT NULL,
  Emp_id INT NOT NULL,
  PRIMARY KEY (D_id),
  FOREIGN KEY (Cust_id) REFERENCES Customer(Cust_id),
  FOREIGN KEY (Order_id) REFERENCES Order(Order_id),
  FOREIGN KEY (Emp_id) REFERENCES Employees(Emp_id)
);