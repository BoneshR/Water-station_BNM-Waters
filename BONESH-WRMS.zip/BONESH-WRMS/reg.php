<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wrms";

$con = mysqli_connect('localhost','root', '');
if($con){
    echo "connection successful";
}
else{
    echo "connection un-successful";
}
mysqli_select_db($con,'wrms');

$username = $_POST['user'];
$email = $_POST['email'];
$password = $_POST['pass'];

$query = "select * from signin where email = '$email' ";
$result = mysqli_query($con , $query);
$num = mysqli_num_rows($result);

if($num == 1) {
    echo " Data is already present";
    exit();
}
else{
    $qy = " insert into signin(user,email,pass) values ('$username','$email','$password')";
    mysqli_query($con,$qy);
    header("Location: home.html");
    exit();
}



?>