<?php
    session_start();
    if(!isset($_SESSION["session_accountname"]) && !isset($_SESSION["session_id"])){
        header("location: /BONESH-WRMS/login.php");
    }
    else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="60">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
   
    <title>BNM Water Refilling Services</title>
    <link href="/BONESH-WRMS/css/admin/dash.css" rel="stylesheet" media="screen">
    <link href="/BONESH-WRMS/headeradmin.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css">

</head>
<body>
    <div class="left-aside">
        <ul><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/index.php"><b style="color:White;">  DASHBOARD &nbsp<i class="fa fa-cart-plus"></i></b></a>
            </li><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/inventory.php"><b style="color:White;">INVENTORY &nbsp<i class="fa fa-list"></i></b></a>
            </li><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/employees.php"><b style="color:White;">EMPLOYEES &nbsp<i class="fa fa-users"></i></b></a>
            </li><br/>
            <li id="head2">
               <a href="/BONESH-WRMS/admin/logout.php"><b style="color:White;">LOGOUT &nbsp<i class="fa fa-times-circle"></i></b></a>
            </li>
             
             
        </ul>
    </div>
    <div style="background-color:black;" id="dashboardTextCont">
        <span id="dashboardTextTop"><b style="color:white;">BNM Water Refilling Services</b></span>
    </div>
    <div id="orderNotificationContainer">
        <div id="headerOrderNotificationContainer">
            <span id="headerOrderNotification">RECENT CUSTOMER ORDERS:</span>
        </div>
        <div id="orderNotification">
            <?php
                include("include/connect.php");

                $query = mysqli_query($con, "SELECT * FROM customerorders ORDER BY ordercustomerid DESC LIMIT 5");
                $countquery = mysqli_num_rows($query);

                if($countquery != 0){
                    while($row = mysqli_fetch_assoc($query)){
                        $orderid = $row['ordercustomerid'];
                        $ordername = $row['ordercustomername'];
                        $orderneeded = $row['orderdateneeded'];
                        $ordernum = $row['ordernumber'];
                        $ordertyp = $row['ordertype'];
                    ?>
                    <div class="showNewOrderContainer">
                        <div id="showNewOrder">
                            <div id="customerNameContainer" class="inlineContext">
                                <div id="customerShowContainer" class="inlineContext">
                                    <form action="" method="post" class="inlineContext">
                                        <button type="submit" id="buttonOne" name="buttonOne">
                                            <img src="/BONESH-WRMS/images/icons/admin/eye.png" alt="SHOW" id="customerShowIcon">
                                            <input type="hidden" name="customerId" id="customerId" value="<?php echo $orderid ?>">
                                        </button>
                                    </form>
                                </div>
                                <span id="customerName">
                                    <?php
                                        echo $ordername;
                                    ?>
                                    :
                                </span>
                                <span id="customerDateNeeded">
                                    <?php
                                        echo $orderneeded;
                                    ?>
                                     - 
                                </span>
                                <span id="customerNum">
                                    <?php
                                        echo $ordernum;
                                    ?>
                                </span>
                                <span id="customerType">
                                    <?php
                                        echo $ordertyp;
                                    ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <?php
                    }
                }
                else{
                    ?>
                    <div class="noResults">
                        No results found!
                    </div>
                    <?php
                }
            ?>
        </div>
    </div>
    <?php
        if(isset($_POST['buttonOne'])){
            $id = $_POST['customerId'];

            $select = mysqli_query($con, "SELECT * FROM customerorders WHERE ordercustomerid='$id'");
            $count = mysqli_num_rows($select);

            if($count != 0){
                while($row = mysqli_fetch_assoc($select)){
                    ?>
                    <div id="detailsContainer">
                        <div id="details">
                            <div id="exitContainer">
                                <span id="exitIconCont" onclick="hideDetails()"><img src="/BONESH-WRMS/images/icons/admin/exit.png" id="exitIcon"></span>
                            </div>
                            <div id="idContainer">
                                <span class="DescText">Customer ID: </span><span class="ResultText"><?php echo $row['ordercustomerid'] ?></span>
                            </div>
                            <div id="nameContainer">
                                <span class="DescText">Customer Name: </span><span class="ResulText"><?php echo $row['ordercustomername'] ?></span>
                            </div>
                            <div id="addressContainer">
                                <span class="DescText">Address: </span><span class="ResultText"><?php echo $row['orderaddress'] ?></span>
                            </div>
                            <div id="contactnumContainer">
                                <span class="DescText">Contact Number: </span><span class="ResultText"><?php echo $row['ordercontactdetails'] ?></span>
                            </div>
                            <div id="dateorderedContainer">
                                <span class="DescText">Date Ordered: </span><span class="ResultText"><?php echo $row['orderdateordered'] ?></span>
                            </div>
                            <div id="dateneededContainer">
                                <span class="DescText">Date of Delivery: </span><span class="ResultText"><?php echo $row['orderdateneeded'] ?></span>
                            </div>
                            <div id="numorderContainer">
                                <span class="DescText">Number of Order: </span><span class="ResultText"><?php echo $row['ordernumber'] ?></span>
                            </div>
                            <div id="typeContainer">
                                <span class="DescText">Type of Container: </span><span class="ResultText"><?php echo $row['ordertype'] ?></span>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
            else{
            ?>
                <script>
                    alert("No data read!");
                </script>
            <?php
            }
        }
    ?>
    <div id="orderNotificationTwoContainer">
        <div id="headerOrderNotificationContainer">
            <span id="headerOrderNotification">FOR TODAY'S DELIVERY:</span>
        </div>
        <div id="orderNotification">
            <?php
                date_default_timezone_set("Asia/Manila");
                $Today = date('F d, Y');

                include("include/connect.php");

                $sql = mysqli_query($con, "SELECT * FROM customerorders WHERE orderdateneeded='$Today' ORDER BY ordercustomerid DESC LIMIT 5");
                $checkquery = mysqli_num_rows($sql);

                if($checkquery != 0){
                    while($row = mysqli_fetch_assoc($sql)){
                        $orderid = $row['ordercustomerid'];
                        $ordername = $row['ordercustomername'];
                        $orderneeded = $row['orderdateneeded'];
                        $ordernum = $row['ordernumber'];
                        $ordertyp = $row['ordertype'];
                    ?>
                    <div class="showNewOrderContainer">
                        <div id="showNewOrder">
                            <div id="customerNameContainer" class="inlineContext">
                                <div id="customerShowContainer" class="inlineContext">
                                    <form action="" method="post" class="inlineContext">
                                        <button type="submit" id="buttonTwo" name="buttonTwo">
                                            <img src="/BONESH-WRMS/images/icons/admin/eye.png" alt="SHOW" id="customerShowIcon">
                                            <input type="hidden" name="customerId" id="customerId" value="<?php echo $orderid ?>">
                                        </button>
                                    </form>
                                </div>
                                <span id="customerName">
                                    <?php
                                        echo $ordername;
                                    ?>
                                    :
                                </span>
                                <span id="customerDateNeeded">
                                    <?php
                                        echo $orderneeded;
                                    ?>
                                     - 
                                </span>
                                <span id="customerNum">
                                    <?php
                                        echo $ordernum;
                                    ?>
                                </span>
                                <span id="customerType">
                                    <?php
                                        echo $ordertyp;
                                    ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <?php
                    }
                }
                else{
                ?>
                    <div class="noResults">
                        No results found!
                    </div>
                <?php
                }
            ?>
        </div>
    </div>
    <?php
        if(isset($_POST['buttonTwo'])){
            $id = $_POST['customerId'];

            $select = mysqli_query($con, "SELECT * FROM customerorders WHERE ordercustomerid='$id'");
            $count = mysqli_num_rows($select);

            if($count != 0){
                while($row = mysqli_fetch_assoc($select)){
                    ?>
                    <div id="detailsContainer">
                        <div id="details">
                            <div id="exitContainer">
                                <span id="exitIconCont" onclick="hideDetails()"><img src="/BONESH-WRMS/images/icons/admin/exit.png" id="exitIcon"></span>
                            </div>
                            <div id="idContainer">
                                <span class="DescText">Customer ID: </span><span class="ResultText"><?php echo $row['ordercustomerid'] ?></span>
                            </div>
                            <div id="nameContainer">
                                <span class="DescText">Customer Name: </span><span class="ResulText"><?php echo $row['ordercustomername'] ?></span>
                            </div>
                            <div id="addressContainer">
                                <span class="DescText">Address: </span><span class="ResultText"><?php echo $row['orderaddress'] ?></span>
                            </div>
                            <div id="contactnumContainer">
                                <span class="DescText">Contact Number: </span><span class="ResultText"><?php echo $row['ordercontactdetails'] ?></span>
                            </div>
                            <div id="dateorderedContainer">
                                <span class="DescText">Date Ordered: </span><span class="ResultText"><?php echo $row['orderdateordered'] ?></span>
                            </div>
                            <div id="dateneededContainer">
                                <span class="DescText">Date of Delivery: </span><span class="ResultText"><?php echo $row['orderdateneeded'] ?></span>
                            </div>
                            <div id="numorderContainer">
                                <span class="DescText">Number of Order: </span><span class="ResultText"><?php echo $row['ordernumber'] ?></span>
                            </div>
                            <div id="typeContainer">
                                <span class="DescText">Type of Container: </span><span class="ResultText"><?php echo $row['ordertype'] ?></span>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
            else{
            ?>
                <script>
                    alert("No data read!");
                </script>
            <?php
            }
        }
    ?>
    <div id="countStatContainer">
        <div id="countStatOne">
            <div id="boxCountStatOne">
                <div id="countOneDesc">Number of pending deliveries for today:</div>
                <div id="statresultOne">
                    <?php
                        date_default_timezone_set("Asia/Manila");
                        $dateToday = date('Y-m-d');

                        $statOne = mysqli_query($con, "SELECT * FROM customerorders WHERE orderdateneeded='$dateToday'");
                        $countOne = mysqli_num_rows($statOne);

                        echo $countOne;
                    ?>
                </div>
            </div>
        </div>
        
    </div>
    <script src="/BONESH-WRMS/js/indexadmin.js"></script>
</body>
</html>
<?php
    }
?>