<?php
    session_start();
    if(!isset($_SESSION["session_accountname"]) && !isset($_SESSION["session_id"])){
        header("location: /BONESH-WRMS/login.php");
    }
    else{
        error_reporting("E-NOTICE");
        include("include/connect.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="60">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BNM Water Refilling Services</title>
    <link href="/BONESH-WRMS/css/admin/employees.css" rel="stylesheet" media="screen">
    <link href="/BONESH-WRMS/headeremployees-add.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css">

</head>
<body>
    <div class="left-aside">
        <ul><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/index.php"><b style="color:White;">  DASHBOARD &nbsp<i class="fa fa-cart-plus"></i></b></a>
            </li><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/inventory.php"><b style="color:White;">INVENTORY &nbsp<i class="fa fa-list"></i></b></a>
            </li><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/employees.php"><b style="color:White;">EMPLOYEES &nbsp<i class="fa fa-users"></i></b></a>
            </li><br/>
            <li id="head2">
               <a href="/BONESH-WRMS/admin/logout.php"><b style="color:White;">LOGOUT &nbsp<i class="fa fa-times-circle"></i></b></a>
            </li>
             
             
        </ul>
    </div>
    <div style="background-color:black;" id="dashboardTextCont">
        <span id="dashboardTextTop"><b style="color:white;">BNM Water Refilling Services</b></span>
    </div>
    <div id="searchfilterContainer">
        <div id="searchfilter">
            <div id="addButtonContainer" class="inlinesearchfilter">
                <button id="addButton" onclick="location.href='/BONESH-WRMS/admin/employees-add.php'">
                    <img src="/BONESH-WRMS/images/icons/admin/add.png" id="addButtonIcon">
                </button>
            </div>
            <div id="searchContainer" class="inlinesearchfilter">
                <form action="employees-search.php" method="POST" class="inlinesearchfilter">
                    <input type="text" name="searchKey" id="searchKey" placeholder="Search">
                    <button type="submit" id="submitSearch" name="submitSearch"><img src="/BONESH-WRMS/images/icons/admin/search.png" id="searchIcon"></button>
                </form>
            </div>
        </div>
    </div>
    <div id="addFormContainer">
        <form action="" method="post" id="addForm">
            <div id="inputNameContainer" class="FormData">
                <input type="text" name="name" id="name" placeholder="Input the Employee Name">
            </div>
            <div id="inputAddressContainer" class="FormData">
                <input type="text" name="address" id="address" placeholder="Input the Employee Address">
            </div>
            <div id="inputContactDetailsCOntainer" class="FormData">
                <input type="text" name="contactnumber" id="contactnumber" placeholder="Input the Employee Contact Details">
            </div>
            <div id="inputPositionContainer" class="FormData">
                <select name="position" id="position">
                    <option value="">Select the Employees Position</option>
                    <option value="Refilling Staff">Refilling Staff</option>
                    <option value="Delivery Staff">Delivery Staff</option>
                </select>
            </div>
            <div id="submitAddContainer">
                <input type="submit" value="ADD NEW EMPLOYEE" id="submitAdd" name="submitAdd">
            </div>
        </form>
    </div>
    <?php
        if(isset($_POST['submitAdd'])){
            if($_POST['name'] != null && $_POST['address'] != null && $_POST['contactnumber'] != null && $_POST['position']){
                $name = $_POST['name'];
                $address = $_POST['address'];
                $contactnum = $_POST['contactnumber'];
                $position = $_POST['position']; 

                $sql = mysqli_query($con, "SELECT * FROM employee WHERE employeename='$name' AND employeeaddress='$address' AND employeecontactdetails='$contactnum' AND employeeposition='$position'");
                $checksql = mysqli_num_rows($sql);

                if($checksql > 0){
                    ?>
                    <script>
                        alert("Employee already existing! Please try again!");
                    </script>
                    <?php
                }
                else{
                    mysqli_query($con, "INSERT INTO employee (employeename, employeeposition, employeeaddress, employeecontactdetails) VALUES ('$name', '$position', '$address', '$contactnum')");
                    ?>
                    <script>
                        alert("New employee successfully added!");
                    </script>
                    <?php
                }
            }
            else{
                ?>
                    <script>
                        alert("Please input all the needed details!");
                    </script>
                <?php
            }
        }
    ?>
</body>
</html>
<?php
    }
?>