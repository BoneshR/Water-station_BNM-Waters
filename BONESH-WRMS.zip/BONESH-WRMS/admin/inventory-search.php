<?php
    session_start();
    if(!isset($_SESSION["session_accountname"]) && !isset($_SESSION["session_id"])){
        header("location: /BONESH-WRMS/login.php");
    }
    else{
        error_reporting("E-NOTICE");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BNM Water Refilling Services</title>
    <link href="/BONESH-WRMS/css/admin/inventory.css" rel="stylesheet" media="screen">
    <link href="/BONESH-WRMS/headeremployees-add.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css">
</head>
<body>
    <div class="left-aside">
        <ul><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/index.php"><b style="color:White;">  DASHBOARD &nbsp<i class="fa fa-cart-plus"></i></b></a>
            </li><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/inventory.php"><b style="color:White;">INVENTORY &nbsp<i class="fa fa-list"></i></b></a>
            </li><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/employees.php"><b style="color:White;">EMPLOYEES &nbsp<i class="fa fa-users"></i></b></a>
            </li><br/>
            <li id="head2">
               <a href="/BONESH-WRMS/admin/logout.php"><b style="color:White;">LOGOUT &nbsp<i class="fa fa-times-circle"></i></b></a>
            </li>   
        </ul>
    </div>
    
    <div style="background-color:black;" id="dashboardTextCont">
        <span id="dashboardTextTop"><b style="color:white;">BNM Water Refilling Services</b></span>
    </div>
    <div id="searchfilterContainer">
        <div id="searchfilter">
             
            <div id="searchContainer" class="inlinesearchfilter">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="inlinesearchfilter">
                    <input type="text" name="searchKey" id="searchKey" placeholder="Search">
                    <button type="submit" id="submitSearch" name="submitSearch"><img src="/BONESH-WRMS/images/icons/admin/search.png" id="searchIcon"></button>
                </form>
            </div>
             
        </div>
    </div>
    <div id="ordersinventoryContainer">
        <div id="ordersinventory">
            <table id="tableOrdersInventory">
                <thead>
                    <tr>
                        <td>Customer Name</td>
                        <td>Customer Address</td>
                        <td>Number of Orders</td>
                        <td>Container Type/Size</td>
                        <td></td>
                    </tr>
                </thead>
            <?php
                include("include/connect.php");
                $searchkey = $_POST['searchKey'];

                $query = mysqli_query($con, "SELECT * FROM customerorders WHERE ordercustomername LIKE '%".$searchkey."%' || orderaddress LIKE '%".$searchkey."%' || orderdateordered LIKE '%".$searchkey."%' || orderdateneeded LIKE '%".$searchkey."%' || ordertype LIKE '%".$searchkey."%' || orderstatus LIKE '%".$searchkey."%'");
                $checkquery = mysqli_num_rows($query);
                if($checkquery != 0){
                    while ($row = mysqli_fetch_assoc($query)){
                        ?>
                <tbody>
                    <tr>
                        <td><?php echo $row['ordercustomername']; ?></td>
                        <td><?php echo $row['orderaddress']; ?></td>
                        <td><?php echo $row['ordernumber']; ?></td>
                        <td><?php echo $row['ordertype']; ?></td>
                        <td><form action="" method="POST">
                            <button type="submit" id="viewSubmit" name="viewSubmit"><img src="/BONESH-WRMS/images/icons/admin/eye.png" id="viewEyeIcon"><input type="hidden" name="viewID" id="viewID" value="<?php echo $row['ordercustomerid']; ?>"></button>
                        </form></td>
                    </tr>     
                        <?php
                    }
                    ?>
                </tbody>
            </table> 
                    <?php
                }
                else{
                ?>
                    <script>
                        alert("No data for the search key!Please try again!");
                        window.location.href = '/BONESH-WRMS/admin/inventory.php';
                    </script>
                <?php
                }
            ?>
        </div>
    </div>
     
    <?php
        if(isset($_POST['submitFilter'])){
            $categoryselected = $_POST['categoryFilter'];

            if ($categoryselected === "CUSTOMER ORDERS"){
                ?>
                <script>
                    window.location.replace(window.location.pathname + window.location.search + window.location.hash);
                </script>
                <?php
            }
            elseif ($categoryselected === "DELIVERED"){
            ?>
            <script>
                document.getElementById('ordersinventoryContainer').style.display = "none";
                document.getElementById('navbar').style.maxWidth = "337.250px";
                document.getElementById('dashboardTextCont').style.paddingLeft = "404.688px";
                document.getElementById('searchfilterContainer').style.paddingLeft = "404.688px";
            </script>
            <div id="deliveredinventoryContainer">
                <div id="deliveredinventory">
                    <table id="tableDeliveredInventory">
                        <thead>
                            <tr>
                                <td>Customer Name</td>
                                <td>Customer Address</td>
                                <td>Number of Orders</td>
                                <td>Container Type/Size</td>
                                <td></td>
                            </tr>
                        </thead>
                    <?php
                        include("include/connect.php");

                        $query = mysqli_query($con, "SELECT * FROM customerorders WHERE orderstatus='DELIVERED' ORDER BY ordercustomerid ASC");
                        $checkquery = mysqli_num_rows($query);
                        if($checkquery != 0){
                            while ($row = mysqli_fetch_assoc($query)){
                                ?>
                        <tbody>
                            <tr>
                                <td><?php echo $row['ordercustomername']; ?></td>
                                <td><?php echo $row['orderaddress']; ?></td>
                                <td><?php echo $row['ordernumber']; ?></td>
                                <td><?php echo $row['ordertype']; ?></td>
                                <td><form action="" method="POST">
                                    <button type="submit" id="viewSubmit" name="viewSubmit"><img src="/BONESH-WRMS/images/icons/admin/eye.png" id="viewEyeIcon"><input type="hidden" name="viewID" id="viewID" value="<?php echo $row['ordercustomerid']; ?>"></button>
                                </form></td>
                            </tr>     
                                <?php
                            }
                        }
                        else{
                        ?>
                            <td colspan="5">No Results for this Category</td>
                        <?php
                        }
                    ?>
                        </tbody>
                    </table> 
                </div>
            </div>
            <?php  
            }
            elseif ($categoryselected === "") {
            ?>
            <script>
                document.getElementById('ordersinventoryContainer').style.display = "none";
                document.getElementById('navbar').style.maxWidth = "337.250px";
                document.getElementById('dashboardTextCont').style.paddingLeft = "404.688px";
                document.getElementById('searchfilterContainer').style.paddingLeft = "404.688px";
            </script>
            <div id="deliveredinventoryContainer">
                <div id="deliveredinventory">
                    <table id="tableDeliveredInventory">
                        <thead>
                            <tr>
                                <td>Customer Name</td>
                                <td>Customer Address</td>
                                <td>Number of Orders</td>
                                <td>Container Type/Size</td>
                                <td></td>
                            </tr>
                        </thead>
                    <?php
                        include("include/connect.php");

                        $query = mysqli_query($con, "SELECT * FROM customerorders WHERE orderstatus='' ORDER BY ordercustomerid ASC");
                        $checkquery = mysqli_num_rows($query);
                        if($checkquery != 0){
                            while ($row = mysqli_fetch_assoc($query)){
                                ?>
                        <tbody>
                            <tr>
                                <td><?php echo $row['ordercustomername']; ?></td>
                                <td><?php echo $row['orderaddress']; ?></td>
                                <td><?php echo $row['ordernumber']; ?></td>
                                <td><?php echo $row['ordertype']; ?></td>
                                <td><form action="" method="POST">
                                    <button type="submit" id="viewSubmit" name="viewSubmit"><img src="/BONESH-WRMS/images/icons/admin/eye.png" id="viewEyeIcon"><input type="hidden" name="viewID" id="viewID" value="<?php echo $row['ordercustomerid']; ?>"></button>
                                </form></td>
                            </tr>     
                                <?php
                            }
                        }
                        else{
                        ?>
                            <td colspan="5">No Results for this Category</td>
                        <?php
                        }
                    ?>
                        </tbody>
                    </table> 
                </div>
            </div>
            <?php
            }
        }
    ?>
    <?php
        if(isset($_POST['viewSubmit'])){
            $viewid = $_POST['viewID'];

            $viewquery = mysqli_query($con, "SELECT * FROM customerorders WHERE ordercustomerid = '$viewid'");
            $checkid = mysqli_num_rows($viewquery);

            if($checkid != 0){
                while ($row = mysqli_fetch_assoc($viewquery)) {
                    ?>
                    <div id="detailsInventoryCont">
                        <div id="detailsInventoryContent">
                            <table align="center" id="detailsInventoryTable">
                                <tr>
                                    <td colspan="2"><div id="exitPic"><img src="/BONESH-WRMS/images/icons/admin/exit.png" id="exitIcon"></div></td>
                                </tr>
                                <tr>
                                    <td>Customer ID:</td>
                                    <td><?php echo $row['ordercustomerid'] ?></td>
                                </tr>
                                <tr>
                                    <td>Customer Name:</td>
                                    <td><?php echo $row['ordercustomername'] ?></td>
                                </tr>
                                <tr>
                                    <td>Address:</td>
                                    <td><?php echo $row['orderaddress'] ?></td>
                                </tr>
                                <tr>
                                    <td>Contact Number:</td>
                                    <td><?php echo $row['ordercontactdetails'] ?></td>
                                </tr>
                                <tr>
                                    <td>Date Ordered:</td>
                                    <td><?php echo $row['orderdateordered'] ?></td>
                                </tr>
                                <tr>
                                    <td>Desire date of Delivery:</td>
                                    <td><?php echo $row['orderdateneeded'] ?></td>
                                </tr>
                                <tr>
                                    <td>Number of Orders:</td>
                                    <td><?php echo $row['ordernumber'] ?></td>
                                </tr>
                                <tr>
                                    <td>Type/Size of Container:</td>
                                    <td><?php echo $row['ordertype'] ?></td>
                                </tr>
                                <tr>
                                    <td>Total Price:</td>
                                    <td><?php echo $row['ordertotal'] ?></td>
                                </tr>
                                <tr>
                                    <td>Order Status:</td>
                                    <td><?php
                                        if($row['orderstatus'] == ""){
                                            echo "FOR DELIVERY";
                                        }
                                        else{
                                            echo $row['orderstatus'];
                                        }
                                    ?></td>
                                </tr>
                                <tr>
                                    <td>Date Delivered:</td>
                                    <td><?php
                                        if($row['orderdatedelivered'] == ""){
                                            echo "---";
                                        }
                                        else{
                                            echo $row['orderdatedelivered'];
                                        }
                                    ?></td>
                                </tr>
                                 
                            </table>
                        </div>
                    </div>
                    <?php
                }
            }
        }
    ?>
    <script src="/BONESH-WRMS/js/inventory.js"></script>
</body>
</html>
<?php
    }
?>