<?php
    session_start();
    if(!isset($_SESSION["session_accountname"]) && !isset($_SESSION["session_id"])){
        header("location: /BONESH-WRMS/login.php");
    }
    else{
        error_reporting("E-NOTICE");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="60">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BNM Water Refilling Services</title>
    <link href="/BONESH-WRMS/css/admin/employees.css" rel="stylesheet" media="screen">
    <link href="/BONESH-WRMS/headeremployees-search.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.2/css/font-awesome.min.css">
</head>
<body>
    <div class="left-aside">
        <ul><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/index.php"><b style="color:White;">  DASHBOARD &nbsp<i class="fa fa-cart-plus"></i></b></a>
            </li><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/inventory.php"><b style="color:White;">INVENTORY &nbsp<i class="fa fa-list"></i></b></a>
            </li><br/>
            <li id="head2">
                <a href="/BONESH-WRMS/admin/employees.php"><b style="color:White;">EMPLOYEES &nbsp<i class="fa fa-users"></i></b></a>
            </li><br/>
            <li id="head2">
               <a href="/BONESH-WRMS/admin/logout.php"><b style="color:White;">LOGOUT &nbsp<i class="fa fa-times-circle"></i></b></a>
            </li>
             
             
        </ul>
    </div>
    <div style="background-color:black;" id="dashboardTextCont">
        <span id="dashboardTextTop"><b style="color:white;">BNM Water Refilling Services</b></span>
    </div>
    <div id="searchfilterContainer">
        <div id="searchfilter">
            <div id="addButtonContainer" class="inlinesearchfilter">
                <button id="addButton" onclick="location.href='/BONESH-WRMS/admin/employees-add.php'">
                    <img src="/BONESH-WRMS/images/icons/admin/add.png" id="addButtonIcon">
                </button>
            </div>
            <div id="searchContainer" class="inlinesearchfilter">
                <form action="employees-search.php" method="POST" class="inlinesearchfilter">
                    <input type="text" name="searchKey" id="searchKey" placeholder="Search">
                    <button type="submit" id="submitSearch" name="submitSearch"><img src="/BONESH-WRMS/images/icons/admin/search.png" id="searchIcon"></button>
                </form>
            </div>
        </div>
    </div>
    <div id="ordersinventoryContainer">
        <div id="ordersinventory">
            <table id="tableOrdersInventory">
                <thead>
                    <tr>
                        <td>Name</td>
                        <td>Address</td>
                        <td>Position</td>
                        <td>Contact Details</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </thead>
            <?php
                include("include/connect.php");
                $searchkey = $_POST['searchKey'];

                $query = mysqli_query($con, "SELECT * FROM employee WHERE employeename LIKE '%".$searchkey."%' || employeeaddress LIKE '%".$searchkey."%' || employeeposition LIKE '%".$searchkey."%' || employeecontactdetails LIKE '%".$searchkey."%'");
                $checkquery = mysqli_num_rows($query);
                if($checkquery != 0){
                    while ($row = mysqli_fetch_assoc($query)){
                        ?>
                <tbody>
                    <tr>
                        <td><?php echo $row['employeename']; ?></td>
                        <td><?php echo $row['employeeaddress']; ?></td>
                        <td><?php echo $row['employeeposition']; ?></td>
                        <td><?php echo $row['employeecontactdetails']; ?></td>
                        <td><form action="" method="POST">
                            <button type="submit" id="viewSubmit" name="viewSubmit"><img src="/BONESH-WRMS/images/icons/admin/eye.png" id="viewEyeIcon"><input type="hidden" name="viewID" id="viewID" value="<?php echo $row['employeeid']; ?>"></button>
                        </form></td>
                         
                    </tr>     
                        <?php
                    }
                    ?>
                </tbody>
            </table> 
                    <?php
                }
                else{
                ?>
                    <script>
                        alert("No data for the search key!Please try again!");
                        window.location.href = '/BONESH-WRMS/admin/employees.php';
                    </script>
                <?php
                    
                }
            ?>
        </div>
    </div>
    <?php
        if(isset($_POST['viewSubmit'])){
            $viewid = $_POST['viewID'];

            $viewquery = mysqli_query($con, "SELECT * FROM employee WHERE employeeid = '$viewid'");
            $checkid = mysqli_num_rows($viewquery);

            if($checkid != 0){
                while ($row = mysqli_fetch_assoc($viewquery)) {
                    ?>
                    <div id="detailsInventoryCont">
                        <div id="detailsInventoryContent">
                            <table align="center" id="detailsInventoryTable">
                                <tr>
                                    <td colspan="2"><div id="exitPic"><img src="/BONESH-WRMS/images/icons/admin/exit.png" id="exitIcon"></div></td>
                                </tr>
                                <tr>
                                    <td>Employee ID:</td>
                                    <td><?php echo $row['employeeid'] ?></td>
                                </tr>
                                <tr>
                                    <td>Employee Name:</td>
                                    <td><?php echo $row['employeename'] ?></td>
                                </tr>
                                <tr>
                                    <td>Address:</td>
                                    <td><?php echo $row['employeeaddress'] ?></td>
                                </tr>
                                <tr>
                                    <td>Contact Number:</td>
                                    <td><?php echo $row['employeecontactdetails'] ?></td>
                                </tr>
                                <tr>
                                    <td>Position:</td>
                                    <td><?php echo $row['employeeposition'] ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <?php
                }
            }
        }
    ?>
    <script src="/BONESH-WRMS/js/employee.js"></script>
</body>
</html>
<?php
    }
?>