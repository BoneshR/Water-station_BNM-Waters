<?php
$url = '/BONESH-WRMS/order.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BNM Water Refilling Service</title>
    <link href="/BONESH-WRMS/css/ordersuccess.css" rel="stylesheet" media="screen">
    <style type="text/css">
         
            body{
                background-image:url('<?php echo $url ?>'); 
                background-repeat:no-repeat;
                background-size:95% 150%;
                
            }    
    </style>
</head>
<body>
     
     
    <div id="orderSuccessMessageContainer">
        <div id="orderSuccessMessage">
            <div id="SuccessContainer">
                <div id="imgSuccessContainer">
                    <img src="/BONESH-WRMS/images/icons/thumbsup.png" alt="SUCCESS" id="imageSuccess">
                </div>
                <div id="completeSuccessContainer">
                    <span id="completeSuccess">Transaction Completed</span>
                </div>
                <div id="txtSuccessContainer">
                    <span id="txtSuccess">Thank you for ordering in BNM Waters!</span>
                </div>
                <div id="buttonPlaceanotherContainer">
                    <button onclick="location.href='/BONESH-WRMS/customer/order.php'" id="buttonPlaceanother">PLACE ANOTHER ORDER</button>
                </div>
                <div id="buttonbackHomepageContainer">
                    <button onclick="location.href='/BONESH-WRMS/home.html'" id="buttonbackHomepage">BACK TO HOMEPAGE</button>
                </div>
            </div>
        </div>
    </div>
    <script src="/BONESH-WRMS/js/ordersuccess.js"></script>
</body>
 
</html>