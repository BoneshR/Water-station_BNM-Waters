<?php
    if(isset($_POST['submitOrder'])){
        include("include/connect.php");

        $customername = $_POST['fullnameOrder'];
        $address = $_POST['addressOrder'];
        $contactdetails = $_POST['contactnumOrder'];
        date_default_timezone_set("Asia/Manila");
		$Today = date('Y-m-d');
        $dateordered = $Today;
        $needed = $_POST['dateneededOrder'];
        $dateneeded = date('Y-m-d', strtotime($needed));
        $numberoforder = $_POST['numberOrder'];
        $type = $_POST['containersizeOrder'];
        $total = $_POST['totalOrder'];
         
        

        mysqli_query($con,"INSERT INTO customerorders (ordercustomername, orderaddress, ordercontactdetails, orderdateordered, orderdateneeded, ordernumber, ordertype, ordertotal ) VALUES ('$customername', '$address', '$contactdetails', '$dateordered', '$dateneeded', '$numberoforder', '$type', '$total' )");

        ?>
        <script>
            alert("Your order is successfully submitted!");
            location.reload();
            window.location = "/BONESH-WRMS/customer/ordersuccess.php";
        </script>
<?php
    }
    $url = '/BONESH-WRMS/order1.png';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>BNM Water Refilling Service</title>
        <link href="/BONESH-WRMS/css/order.css" rel="stylesheet" media="screen">
        <style type="text/css">
         
         body{
             background-image:url('<?php echo $url ?>'); 
             background-repeat:no-repeat;
             background-size:100% 100%;
            }    
        </style>
    </head>
    <body>
        <div class="container"> 
            <div class="form"> 
                <div class="center">
                     <div id="formOrderContainer">
                        <div id="welcomeCustomerContainer">
                          <span style="color:black;font-size:40px;" id="welcomeCustomer">Welcome Customer!</span>
                        </div>
                        <div id="filloutDetailsContainer">
                            <span id="filloutDetails">Please fill out the details below:</span>
                        </div>
                            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" id="formOrder">
                                <div id="orderDetailsContainer">
                                    <div id="fullnameOrderContainer">
                                        <input type="text" name="fullnameOrder" id="fullnameOrder" placeholder="Enter your full name" required>
                                    </div><br/>
                                    <div id="addressOrderContainer">
                                        <input type="text" name="addressOrder" id="addressOrder" placeholder="Enter your current address" required>
                                    </div><br/>
                                    <div id="contactnumOrderContainer">
                                        <input type="text" name="contactnumOrder" id="contactnumOrder" placeholder="Enter your contact details" required>
                                    </div><br/>
                                    <div id="dateneededOrderContainer">
                                    <?php
                                        date_default_timezone_set("Asia/Manila");
                                        $dateToday = date('Y-m-d');
                                    ?>
                                    Desire date of delivery: <input type="date" name="dateneededOrder" id="dateneededOrder" placeholder="Enter your desire date of delivery" min="<?php echo $dateToday; ?>" required>
                                </div><br/>
                                <div id="numberOrderContainer" class="distinguishOrder">
                                    <input type="number" name="numberOrder" id="numberOrder" min="0" max="5000" placeholder="Number of orders" required>
                                </div><br/><br/>
                                <div id="containersizeOrderContainer" class="distinguishOrder">
                                    <input type="radio" name="containersizeOrder" id="tanker1" value="tanker1">3000 Ltrs
                                    <input type="radio" name="containersizeOrder" id="tanker2" value="tanker2">5000 Ltrs
                                    <input type="radio" name="containersizeOrder" id="tanker3" value="tanker3">10000 Ltrs
                                </div><br/>
                                <div id="totalOrderContainer">
                                    Total Amount of Order: <input type="text" name="totalOrder" id="totalOrder" required>
                                </div> 
                                <div id="pictureOrderContainer">
                                    <img src="" id="pictureOrder">
                                </div>
                                <div id="proceedOrderContainer">
                                    <input type="button" value="PROCEED" id="proceedOrder" name="proceedOrder" onclick="showOrder()">
                                </div>
                            </div>
                            <div id="submitOrderContainer">
                                <input type="submit" value="ORDER" id="submitOrder" name="submitOrder">
                            </div>
                        </form>
                        <a  style="padding-left:1%;" href ="/BONESH-WRMS/home.html"><button class="button2">Back to Home Page</button></a>
                    </div>
                    <script src="/BONESH-WRMS/js/order.js"></script>
                    <script src="/BONESH-WRMS/js/totalorder.js"></script>
                </div>
            </div>
</body>
 
</html>